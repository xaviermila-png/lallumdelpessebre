@echo off
setlocal enabledelayedexpansion
title Instal-lador de firmware ARDMX EVO

echo ============================================
echo   Instal-lador de firmware - ARDMX EVO
echo   (versio autonoma, no cal res mes instalat)
echo ============================================
echo.

set "ESPTOOL=%~dp0esptool.exe"
set "BINDIR=%~dp0bin"

if exist "%BINDIR%\version.txt" (
    type "%BINDIR%\version.txt"
    echo.
)

if not exist "%ESPTOOL%" (
    echo ERROR: no es troba esptool.exe al costat d'aquest script.
    goto :fi
)

if not exist "%BINDIR%\firmware.bin" (
    echo ERROR: falten els fitxers de firmware a la carpeta "bin".
    goto :fi
)

echo Ports serie disponibles:
echo.
set "AUTOPORT="
for /f "usebackq tokens=1,* delims=:" %%A in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0detect_port.ps1"`) do (
    if "%%A"=="LIST" echo   - %%B
    if "%%A"=="RECOMMENDED" set "AUTOPORT=%%B"
)
echo.

if defined AUTOPORT (
    echo Port recomanat, sembla l'ESP32: %AUTOPORT%
    echo.
    set /p COMPORT="Escriu el port COM, o prem Enter per fer servir %AUTOPORT%: "
    if "!COMPORT!"=="" set "COMPORT=!AUTOPORT!"
) else (
    set /p COMPORT="Escriu el port COM del ESP32, per exemple COM10, i prem Enter: "
)

if "%COMPORT%"=="" (
    echo No has escrit cap port. Sortint.
    goto :fi
)

echo.
echo ATENCIO: aquest instal-lador actualitzara el firmware de l'ARDMX EVO a
echo la versio indicada mes amunt, i ESBORRARA TOTA la configuracio desada
echo al dispositiu (canals, escenes, events, pessebre, nom Bluetooth,
echo PIN...), deixant-lo com de fabrica.
echo.
echo Si vols conservar la configuracio actual: CANCEL·LA ara, ves a la
echo pantalla "Configuracio" de l'app i fes una EXPORTACIO (fitxer JSON).
echo Un cop instal-lat aquest firmware, podras IMPORTAR aquest fitxer per
echo recuperar canals/escenes/events/pessebre/descripcio -- pero no el nom
echo Bluetooth ni el PIN, que l'exportacio no inclou i hauras de tornar a
echo configurar a ma si els havies canviat.
echo.
set /p CONFIRM="Vols continuar? (s/n): "
if /i not "%CONFIRM%"=="s" (
    echo Cancel·lat.
    goto :fi
)

echo.
echo Esborrant la configuracio anterior (NVS)...
echo.

"%ESPTOOL%" --chip esp32 --port %COMPORT% --baud 460800 ^
    erase-region 0x10000 0x10000

if errorlevel 1 (
    echo.
    echo ============================================
    echo   Hi ha hagut un error esborrant la configuracio.
    echo   Comprova que el port es correcte i que
    echo   el cable USB esta be endollat.
    echo ============================================
    goto :fi
)

echo.
echo Flashejant %COMPORT%... no desendollis el cable.
echo.

"%ESPTOOL%" --chip esp32 --port %COMPORT% --baud 460800 ^
    --before default-reset --after hard-reset write-flash ^
    --flash-mode dio --flash-freq 40m --flash-size detect ^
    0x1000 "%BINDIR%\bootloader.bin" ^
    0x8000 "%BINDIR%\partitions.bin" ^
    0x20000 "%BINDIR%\firmware.bin"

if errorlevel 1 (
    echo.
    echo ============================================
    echo   Hi ha hagut un error flashejant.
    echo   Comprova que el port es correcte i que
    echo   el cable USB esta be endollat.
    echo ============================================
) else (
    echo.
    echo ============================================
    echo   Firmware instal-lat correctament.
    echo ============================================
)

:fi
echo.
pause
